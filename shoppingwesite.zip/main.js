
$(document).ready(function () {
    $(".owl-carousel.three-Collection").owlCarousel({
        loop: true,
        margin: 20,
        nav: true,
        dots: true,
        autoplay: true,
        autoplayTimeout: 3000,
        // span:  a ,
        navText: [
            '<i class="fa fa-chevron-left"></i>', 
            '<i class="fa fa-chevron-right"></i>'
        ],
        autoplayHoverPause: true,
        responsive: {
            0: { items: 1 },
            600: { items: 2 },
            1000: { items: 6 }
        }
    });
});

$(document).ready(function () {
    $(".owl-carousel.one-Collection").owlCarousel({
        loop: true,
        margin: 20,
        nav: true,
        dots: true,
        autoplay: true,
        autoplayTimeout: 3000,
        // span:  a ,
        navText: [
            '<i class="fa fa-chevron-left"></i>', 
            '<i class="fa fa-chevron-right"></i>'
        ],
        autoplayHoverPause: true,
        responsive: {
            0: { items: 1 },
            600: { items: 2 },
            1000: { items: 1 }
        }
    });
});

